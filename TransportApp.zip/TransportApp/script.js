const loadElementArray = [];
const featElementArray = [];
const typeElementArray = [];
const inputText = document.querySelector("#input-text");
const searchBtn = document.getElementById("search-btn");
const outPanel = document.querySelector("#panel-output");
const busNum = document.querySelector(".bus-num");
const destCode = document.querySelector(".dest-code");
const template = document.querySelector(".bus-output-panel");
const accKey =  'zdizZc8xTyCj7yKmxA0Dgg==';

for(let i = 1; i <= 3; i++){
    const element = document.querySelector(`#load${i}`);
    if(element)
        loadElementArray.push(element);
}
for(let i = 1; i <= 3; i++){
    const element = document.querySelector(`#feature${i}`);
    if(element)
        featElementArray.push(element);
}
for(let i = 1; i <= 3; i++){
    const element = document.querySelector(`#type${i}`);
    if(element)
        typeElementArray.push(element);
}

async function getData(busStopCode) {
    try {
        // alert(busStopCode);
        const apiURL = `https://proxy.cors.sh/https://datamall2.mytransport.sg/ltaodataservice/v3/BusArrival?BusStopCode=${busStopCode}`;
        const response = await fetch(apiURL, {
            headers: {
                AccountKey : accKey,
                Accept: 'application/json'
            }
        });
        if(response.ok){
            alert(`all okay:)))`);
            const data = await response.json();
            if (data.Services) {
                const count = data.Services.length;
                alert(count);
                
                //loop for the number 
                for(let j = 0; j < count; j++)
                {
                    const busNumber = data.Services[j].ServiceNo;
                    const clone = template.cloneNode(true);
                    // clone.style.display = contents;
                    busNum.innerHTML = `Bus ${busNumber}`;
                    for(let i = 0; i < 3; i++) //looping for the detailed feature of the bus
                    {
                        const key = i === 0 ? "NextBus" : `NextBus${i + 1}`
                        loadElementArray[i].innerHTML = data.Services[j][key].Load;
                        featElementArray[i].innerHTML = data.Services[j][key].Feature;
                        typeElementArray[i].innerHTML = data.Services[j][key].Type;
                        destCode.innerHTML = `Dest Postcal Code: ${data.Services[0][key].DestinationCode}`;
                        // alert(i);
                    }
                    outPanel.appendChild(clone);
                }
               
                //get the feature of the bus
            } else {
                outPanel.innerHTML = "No services available for this bus stop.";
            }
        }
        else
            alert(`HTTP Error: ${response.status}`);
    } catch (error) {
        alert("error occured");
        alert(`An error occured ${error.message}`);
    }
    
}



searchBtn.addEventListener("click", () => getData(inputText.value));
// alert(inputText.value);

